package com.company;

public class Spelplan {
}
