package com.company;

public class Gepard {
}
