package com.company;

public class Djur {
}
