package com.company;

public class AI {
}
