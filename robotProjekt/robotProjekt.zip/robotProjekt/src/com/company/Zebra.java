package com.company;

public class Zebra {
}
