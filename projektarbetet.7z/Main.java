package projektarbetet;

public class Main {

    public static void main(String[] args) {
        AI ai = new AI();// creates the ai  object
        ai.createArrays();//calls the createVectors to set all the vectors
        ai.startGame();//starts the game having all the vectors ready.

    }
}
