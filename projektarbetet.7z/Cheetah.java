package projektarbetet;

import java.util.Random;

public class Cheetah extends Animals {
    // removes resting move it to private  boolean resting;
    int steps;
    Random rand;
// set variabel i ceetah
    public Cheetah() {
        resting = false;// move to resting
        rand = new Random();
        steps = 1 + rand.nextInt(1);//gives a random speed at start either 1 or 2.
    }


    public boolean isResting() {
        return resting;
    }

    @Override
    public int getSteps() {// called when moving an animal to keep track on its turn and if it has to rest and getting how many steps to take
        turnCounter++;//adds to turncounter
        setRest();// checks if cheetah has to rest or not
        Direction();// gives a random direction
        return steps;// return how many steps to move 2 or 1
    }

    public void restAfterEating() {
        resting = true;
    }// used when the cheetah eats to make it rest

    public void setRest() {//used to check if the cheetah has moved more then 3 turns then it have to rest
        if (turnCounter == 3) {
            resting = true;
            turnCounter = 0;
        } else {
            resting = false;
        }

    }
}